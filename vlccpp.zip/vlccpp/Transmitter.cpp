#include "stdafx.h"
#include "Transmitter.h"



namespace vlc {

  Transmitter::Transmitter()
  {
  }


  Transmitter::~Transmitter()
  {
  }
}

#include "stdafx.h"
#include "CameraInfo.h"

namespace vlc {


  CameraInfo::CameraInfo()
  {
  }


  CameraInfo::~CameraInfo()
  {
  }

}
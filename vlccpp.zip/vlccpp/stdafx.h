#pragma once
#include <opencv2/opencv.hpp>
#include <iostream>
#include <Windows.h>
#include <string>
#include <vector>
#include <map>
#include "CameraInfo.h"
#include "RoomInfo.h"
#include "Transmitter.h"
#include "Processor.h"
#include "Tools.h"


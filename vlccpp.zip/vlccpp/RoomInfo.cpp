#include "stdafx.h"
#include "RoomInfo.h"
namespace vlc {


  RoomInfo::RoomInfo()
  {
  }


  RoomInfo::~RoomInfo()
  {
  }
}
